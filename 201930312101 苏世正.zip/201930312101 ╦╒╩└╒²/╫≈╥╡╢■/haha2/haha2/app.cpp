#include <iostream>
#include"app.h"
using namespace std; 
void finish()
{
cout<<"����"<<endl;
}