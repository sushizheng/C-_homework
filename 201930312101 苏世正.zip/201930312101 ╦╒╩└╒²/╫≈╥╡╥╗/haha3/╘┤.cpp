#include<iostream>
#include<conio.h>
using namespace  std;
int main()
{
	cout<<"�ҵ�ѧ���ǣ�"<<endl;
	cout<<"****    *   "<<endl;
	cout<<"*  *    *   "<<endl;
	cout<<"*  *    *   "<<endl;
	cout<<"****    *   "<<endl;
	getch();
	return 0;
}