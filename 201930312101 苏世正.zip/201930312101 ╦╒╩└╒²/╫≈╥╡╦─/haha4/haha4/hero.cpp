#include <iostream>
#include "hero.h"
using namespace std;



hero::hero( int xl,int mf,int gj,int sd,int gs,int fq,int mk,int wk)
{
	
   d1=xl;
   d2=mf ;
   d3=gj ;
   d4=sd ;
   d5=gs;
   d6=fq ;
   d7=mk;
   d8=wk;
  
}
void hero ::showd()
{
cout<<"Ӣ��Ѫ��:";cout<<d1 <<endl;
cout<<"Ӣ��ħ��:";cout<< d2 <<endl;
cout<<"Ӣ�۹���:";cout<< d3<<endl;
cout<<"Ӣ���ٶ�:";cout<< d4<<endl;
cout<<"Ӣ�۹���:";cout<< d5 <<endl;
cout<<"Ӣ�۷�ǿ:";cout<< d6<<endl;
cout<<"Ӣ��ħ��:";cout<<d7<<endl;
cout<<"Ӣ���￹:";cout<<d8<<endl;

}

void hero::at()
{
d1= d1-50;
}
void hero::da1 ()
{
d2=d2;
}
void hero::da2 ()
{
d1=d1-100;
}
void haipa()
{

}