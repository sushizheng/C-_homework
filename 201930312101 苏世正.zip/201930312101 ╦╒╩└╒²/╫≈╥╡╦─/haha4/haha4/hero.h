#include <iostream>
using namespace std;
class hero
{
public:
        hero();
		hero( int xl,int mf,int gj,int sd,int gs,int fq,int mk,int wk);
		void showd();
		void at();
		void da1();
		void da2();
		void sh();
		int d1;
	    int d2;
        int d3;
        int d4;
        int d5;
        int d6;
        int d7;
        int d8;
private:

};
void solo();
void huishou();
